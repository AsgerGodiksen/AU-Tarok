The old protocol ("CAN BUS Protocol.pdf"):
This i likely the correct protocol for our actuators.
It is at least so far the one that with data fields correctly corresponding to what works with the actuators.
So use this one as correct protocol.

The new protocol ("Motor Motion Protocol V4.2-250208"):
It is NOT correct with regards to data fields.
But it has more thourough descriptions of commands.
Can be helpful with regards to description but not direct use.